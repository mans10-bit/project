<?php

session_start();
// var_dump($_SESSION);

require_once 'db.php';

if(isset($_GET['deconnexion']) && $_GET['deconnexion'] == '1'){
    session_unset();
    // session_destroy();

    header("Location: index.php");
    exit();
}

require_once 'header.php';

// var_dump($_SESSION);
if(!empty($_SESSION) ){


    if($_SESSION['role'] === 'Administrateur')
    {
        // echo "page Admin";
        require_once("actionA.php");

    }else{

        // echo "page Utilisateur";
        require_once("actionU.php");
    }

    
    
}else
{
    require_once("pageconnexion.php");
}


?>
