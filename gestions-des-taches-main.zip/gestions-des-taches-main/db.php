<?php
$host = "localhost";
$dbname = "gestions_des_taches";
$username = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} 
catch (PDOException $e) {
    die("Erreur connexion : " . $e->getMessage());
}
?>
 