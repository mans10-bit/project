<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

// 1. AJOUTER
if (isset($_POST['action']) && $_POST['action'] === 'ajouter') {
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $statut = $_POST['statut'];
    $idUser = $_SESSION['idUser'];
    
    $sql = "INSERT INTO taches (titre, description, statut, idUser) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$titre, $description, $statut, $idUser]);
    
    header("Location: index.php");
    exit;
}

// 2. SUPPRIMER
if (isset($_GET['supprimer'])) {
    $id = $_GET['supprimer'];
    
    $sql = "DELETE FROM taches WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    
    header("Location: index.php");
    exit;
}

// 3. RÉCUPÉRER POUR MODIFIER
$tache_a_modifier = null;

if (isset($_GET['modifier'])) {
    $id = $_GET["modifier"];
    
    $sql = "SELECT * FROM taches WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    
    $tache_a_modifier = $stmt->fetch();
}

// 4. MODIFIER
if (isset($_POST['action']) && $_POST['action'] === 'modifier') {
    $id = $_POST["id"];
    $titre = $_POST["titre"];
    $description = $_POST["description"];
    $statut = $_POST["statut"];
    
    $sql = "UPDATE taches 
            SET titre = ?, description = ?, statut = ?
            WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$titre, $description, $statut, $id]);
    
    header("Location: index.php");
    exit;
}

// 5. RÉCUPÉRER LISTE DES TACHES AVEC FILTRES
$conditions = ["idUser = {$_SESSION['idUser']}"];
$params = [];

// Filtre par statut
if (isset($_GET['statut']) && !empty($_GET['statut']) && $_GET['statut'] !== 'tous') {
    $conditions[] = "statut = ?";
    $params[] = $_GET['statut'];
}

// Recherche par mot-clé
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $conditions[] = "(titre LIKE ? OR description LIKE ?)";
    $searchTerm = "%" . $_GET['search'] . "%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Construction de la requête
$sql = "SELECT * FROM taches WHERE " . implode(" AND ", $conditions) . " ORDER BY titre ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$taches = $stmt->fetchAll();

// Récupérer les statistiques pour l'utilisateur courant
$sql_stats = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN statut = 'en cours' THEN 1 ELSE 0 END) as en_cours,
    SUM(CASE WHEN statut = 'terminée' THEN 1 ELSE 0 END) as terminees
    FROM taches 
    WHERE idUser = ?";
    
$stmt_stats = $pdo->prepare($sql_stats);
$stmt_stats->execute([$_SESSION['idUser']]);
$stats = $stmt_stats->fetch();

include_once 'header.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= isset($titre) ? $titre : 'Gestion des Tâches' ?></title>
    <!-- Bootstrap et CSS existants -->
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="col-md-8 offset-2 row">
            <h1 class="mb-3 col-8">Gestion des Tâches</h1>
            <a class="col-2 mt-2 mb-3 btn btn-danger text-center" href="index.php?deconnexion=1">Déconnexion</a> 
        </div>

        <!-- ==== STATISTIQUES UTILISATEUR ==== -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total des tâches</h5>
                        <h2 class="card-text"><?= $stats['total'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">En cours</h5>
                        <h2 class="card-text"><?= $stats['en_cours'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Terminées</h5>
                        <h2 class="card-text"><?= $stats['terminees'] ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==== FORMULAIRES DE RECHERCHE ET FILTRE ==== -->
        <div class="card mb-4">
            <div class="card-header bg-secondary text-white">
                Rechercher et filtrer les tâches
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Recherche par mot-clé</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" 
                                   value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
                                   placeholder="Rechercher dans les titres et descriptions">
                            <button class="btn btn-outline-primary" type="submit">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Filtrer par statut</label>
                        <select class="form-select" name="statut">
                            <option value="tous" <?= (!isset($_GET['statut']) || $_GET['statut'] == 'tous') ? 'selected' : '' ?>>Tous les statuts</option>
                            <option value="en cours" <?= (isset($_GET['statut']) && $_GET['statut'] == 'en cours') ? 'selected' : '' ?>>En cours</option>
                            <option value="terminée" <?= (isset($_GET['statut']) && $_GET['statut'] == 'terminée') ? 'selected' : '' ?>>Terminée</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2 d-flex align-items-end mb-3">
                        <button type="submit" class="btn btn-primary w-100">Appliquer</button>
                        <?php if (isset($_GET['search']) || isset($_GET['statut'])): ?>
                            <a href="index.php" class="btn btn-outline-secondary ms-2">Réinitialiser</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- ==== FORMULAIRE AJOUT / MODIFICATION ==== -->
        <div class="card mb-4 col-md-8 offset-2">
            <div class="card-header bg-primary text-white">
                <?= $tache_a_modifier ? "Modifier une tâche" : "Ajouter une tâche" ?>
            </div>
            <div class="card-body">
                <form method="POST" action="actionU.php">
                    <input type="hidden" name="action" value="<?= $tache_a_modifier ? "modifier" : "ajouter" ?>">
                    <?php if ($tache_a_modifier): ?>
                        <input type="hidden" name="id" value="<?= $tache_a_modifier['id'] ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label">Titre</label>
                        <input type="text" class="form-control" name="titre" required
                            value="<?= $tache_a_modifier['titre'] ?? '' ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3"><?= $tache_a_modifier['description'] ?? '' ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Statut</label>
                        <select class="form-select" name="statut">
                            <option value="en cours" <?= isset($tache_a_modifier) && $tache_a_modifier['statut'] == "en cours" ? "selected" : "" ?>>En cours</option>
                            <option value="terminée" <?= isset($tache_a_modifier) && $tache_a_modifier['statut'] == "terminée" ? "selected" : "" ?>>Terminée</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success">
                        <?= $tache_a_modifier ? "Enregistrer les modifications" : "Ajouter la tâche" ?>
                    </button>

                    <?php if ($tache_a_modifier): ?>
                        <a href="index.php" class="btn btn-secondary">Annuler</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- ==== LISTE DES TÂCHES ==== -->
        <h2 class="mb-3">Liste des tâches 
            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
                <small class="text-muted">(Résultats pour "<?= htmlspecialchars($_GET['search']) ?>")</small>
            <?php endif; ?>
            <?php if (isset($_GET['statut']) && $_GET['statut'] !== 'tous'): ?>
                <small class="text-muted">(Filtré par statut: <?= htmlspecialchars($_GET['statut']) ?>)</small>
            <?php endif; ?>
        </h2>

        <?php if (!empty($taches)): ?>
            <div class="row">
                <?php foreach ($taches as $tache): ?>
                    <div class="col-md-4">
                        <div class="card mb-3 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($tache['titre']) ?></h5>
                                <p class="card-text"><?= htmlspecialchars($tache['description']) ?></p>
                                <span class="badge bg-<?= $tache['statut'] == "terminée" ? "success" : "warning" ?>">
                                    <?= $tache['statut'] ?>
                                </span>
                                <small class="text-muted d-block mt-2">
                                    Créé le: <?= date('d/m/Y', strtotime($tache['created_at'] ?? 'now')) ?>
                                </small>
                                <hr>
                                <a href="index.php?modifier=<?= $tache['id'] ?>" class="btn btn-sm btn-primary">
                                    Modifier
                                </a>
                                <a href="index.php?supprimer=<?= $tache['id'] ?>"
                                    class="btn btn-sm btn-danger"
                                    onclick="return confirm('Supprimer cette tâche ?');">
                                    Supprimer
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <?php if (isset($_GET['search']) || isset($_GET['statut'])): ?>
                    Aucune tâche ne correspond à vos critères de recherche.
                <?php else: ?>
                    Pas de tâche à afficher. Commencez par en créer une !
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>