<?php
include_once('header.php');

if (isset($_POST["connexion"])) {

    $login = ($_POST["login"]);
    $mdp = ($_POST["motdepasse"]);

    // seurisation du mot de passe avec sha1
    $hash=sha1($mdp);
    // var_dump($hash);

    
    // preparation et execution de la requete
    $sql = "SELECT * from users where login=? AND password=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$login, $hash]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    // var_dump($user);

    if ($user) {
        $_SESSION["prenom"] = $user["prenom"];
        $_SESSION["nom"] = $user["nom"];
        $_SESSION["role"]= $user["role"];
        $_SESSION["idUser"]= $user["idUser"];
        header("Location: index.php");
        exit;
    } 
    

}
?> 
<div class="col-md-8 offset-2 mt-5">
    <form action="" method="POST">
        <label for="">Login</label>
            <input type="text" name="login" class="form-control">
            <br>
            <label for="">Password</label>
            <input type="password" name="motdepasse" class="form-control">
            <br>
            <?php
                if (isset($_POST["connexion"])) {
                    if (!$user){
                        echo "<div class='alert alert-danger'>Login ou mot de passe incorrect</div>";
                    }
                }
            ?>
            <button type="submit" name="connexion" class="btn btn-success">Se Connecter</button>
     </form>
</div>