<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$titre = "Gestion Des Utilisateurs";
require_once 'header.php';
include 'db.php';

// 1. AJOUTER
if (isset($_POST['action']) && $_POST['action'] === 'ajouter') {
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $role = $_POST['role'];
    $login = $_POST['login'];
    $password = sha1($_POST['password']);

    $sql = "INSERT INTO users (prenom, nom, role, login, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$prenom, $nom, $role, $login, $password]);

    header("Location: index.php");
    exit;
}

// 2. SUPPRIMER UTILISATEUR
if (isset($_GET['supprimeruser'])) {
    $id = $_GET['supprimeruser'];
    $sql = "DELETE FROM users WHERE idUser = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    header("Location: index.php");
    exit;
}

// 2. SUPPRIMER TACHE
if (isset($_GET['supprimer'])) {
    $id = $_GET['supprimer'];
    $sql = "DELETE FROM taches WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    header("Location: index.php");
    exit;
}

// 3. RÉCUPÉRER POUR MODIFIER
$user_a_modifier = null;
if (isset($_GET['modifieruser'])) {
    $id = $_GET["modifieruser"];
    $sql = "SELECT * FROM users WHERE idUser = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $user_a_modifier = $stmt->fetch();
}

// 4. MODIFIER
if (isset($_POST['action']) && $_POST['action'] === 'modifier') {
    $id = $_POST["idUser"];
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $role = $_POST['role'];
    $login = $_POST['login'];
    
    if(empty($_POST['password'])){
        $password = $user_a_modifier['password'];
    } else {
        $password = sha1($_POST['password']);
    }

    if(isset($_GET['modifieruser']) && $user_a_modifier['role'] === 'Utilisateur' && $user_a_modifier['role'] !== $_POST['role']){
        $id_a_modifier = $_GET['modifieruser'];
        $sql = "DELETE FROM taches WHERE idUser = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id_a_modifier]);
    }

    $sql = "UPDATE users 
            SET prenom = ?, nom = ?, role = ?, login = ?, password = ?
            WHERE idUser = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$prenom, $nom, $role, $login, $password, $id]);

    header("Location: index.php");
    exit;
}

// RÉCUPÉRER STATISTIQUES GLOBALES
$sql_stats = "SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM users WHERE role = 'Administrateur') as admin_count,
    (SELECT COUNT(*) FROM users WHERE role = 'Utilisateur') as user_count,
    (SELECT COUNT(*) FROM taches) as total_taches,
    (SELECT COUNT(*) FROM taches WHERE statut = 'en cours') as taches_en_cours,
    (SELECT COUNT(*) FROM taches WHERE statut = 'terminée') as taches_terminees,
    (SELECT COUNT(DISTINCT idUser) FROM taches) as users_avec_taches";

$stats = $pdo->query($sql_stats)->fetch(PDO::FETCH_ASSOC);

// RÉCUPÉRER LISTE DES UTILISATEURS
$users = $pdo->query("SELECT * FROM users ORDER BY nom, prenom")->fetchAll(PDO::FETCH_ASSOC);

// RÉCUPÉRER LISTE DES TÂCHES AVEC FILTRES
$conditions = ["1=1"];
$params = [];

// Filtre par statut
if (isset($_GET['statut']) && !empty($_GET['statut']) && $_GET['statut'] !== 'tous') {
    $conditions[] = "t.statut = ?";
    $params[] = $_GET['statut'];
}

// Recherche par mot-clé
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $conditions[] = "(t.titre LIKE ? OR t.description LIKE ? OR u.prenom LIKE ? OR u.nom LIKE ?)";
    $searchTerm = "%" . $_GET['search'] . "%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Construction de la requête
$sql_taches = "SELECT t.*, u.prenom, u.nom, u.role 
               FROM taches t 
               JOIN users u ON t.idUser = u.idUser 
               WHERE " . implode(" AND ", $conditions) . " 
               ORDER BY t.titre ASC";

$stmt_taches = $pdo->prepare($sql_taches);
$stmt_taches->execute($params);
$taches = $stmt_taches->fetchAll();
?>

<body class="bg-light">
    <div class="container mt-5">
        <!-- En-tête avec déconnexion -->
        <div class="row">
            <div class="col-7">
                <div class="row">
                    <h1 class="mb-3 col-10">Gestion des Utilisateurs</h1>
                    <a class="col-2 mt-2 mb-3 btn btn-danger h- text-center" href="index.php?deconnexion=1">Déconnexion</a> 
                </div>
            </div>
            <div class="col-5">
                <h1 class="text-center mb-4 mt-1">UTILISATEURS</h1>
            </div>
        </div>

        <!-- ==== STATISTIQUES GLOBALES ==== -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Utilisateurs</h5>
                        <h2 class="card-text"><?= $stats['total_users'] ?></h2>
                        <small>Admin: <?= $stats['admin_count'] ?> | Users: <?= $stats['user_count'] ?></small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h5 class="card-title">Tâches totales</h5>
                        <h2 class="card-text"><?= $stats['total_taches'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">Tâches en cours</h5>
                        <h2 class="card-text"><?= $stats['taches_en_cours'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Tâches terminées</h5>
                        <h2 class="card-text"><?= $stats['taches_terminees'] ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==== FORMULAIRE DE RECHERCHE ET FILTRE ==== -->
        <div class="card mb-4">
            <div class="card-header bg-secondary text-white">
                Rechercher et filtrer les tâches
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Recherche</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" 
                                   value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
                                   placeholder="Tâches, descriptions, utilisateurs...">
                            <button class="btn btn-outline-primary" type="submit">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Filtrer par statut</label>
                        <select class="form-select" name="statut">
                            <option value="tous" <?= (!isset($_GET['statut']) || $_GET['statut'] == 'tous') ? 'selected' : '' ?>>Tous les statuts</option>
                            <option value="en cours" <?= (isset($_GET['statut']) && $_GET['statut'] == 'en cours') ? 'selected' : '' ?>>En cours</option>
                            <option value="terminée" <?= (isset($_GET['statut']) && $_GET['statut'] == 'terminée') ? 'selected' : '' ?>>Terminée</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2 d-flex align-items-end mb-3">
                        <button type="submit" class="btn btn-primary w-100">Appliquer</button>
                        <?php if (isset($_GET['search']) || isset($_GET['statut'])): ?>
                            <a href="index.php" class="btn btn-outline-secondary ms-2">Réinitialiser</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <!-- Colonne gauche: Formulaire gestion utilisateurs -->
            <div class="col-7">
                <!-- ==== FORMULAIRE AJOUT / MODIFICATION ==== -->
                <div class="card mb-4 col-md-12 offset-3 mx-0">
                    <div class="card-header bg-primary text-white">
                        <span><?= $user_a_modifier ? "Modifier un utilisateur" : "Ajouter un utilisateur  " ?></span>
                    </div>

                    <div class="card-body">
                        <form method="POST" action="">

                            <input type="hidden" name="action" value="<?= $user_a_modifier ? "modifier" : "ajouter" ?>">

                            <?php if ($user_a_modifier): ?>
                                <input type="hidden" name="idUser" value="<?= $user_a_modifier['idUser'] ?>">
                            <?php endif; ?>

                            <div class="mb-3">
                                <label class="form-label">Prénom</label>
                                <input type="text" class="form-control" name="prenom" value="<?= $user_a_modifier['prenom'] ?? '' ?>">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Nom</label>
                                <input type="text" class="form-control" name="nom" value="<?= $user_a_modifier['nom'] ?? '' ?>">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Role</label>
                                <select class="form-select" name="role">
                                    <option value="Utilisateur" <?= isset($user_a_modifier) && $user_a_modifier['role'] == "Utilisateur" ? "selected" : "" ?>>Utilisateur</option>
                                    <option value="Administrateur" <?= isset($user_a_modifier) && $user_a_modifier['role'] == "Administrateur" ? "selected" : "" ?>>Administrateur</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Login</label>
                                <input type="text" class="form-control" name="login" value="<?= $user_a_modifier['login'] ?? '' ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" placeholder="<?= $user_a_modifier ? "Nouveau mot de passe ou Laisser comme ca" : "" ?>" <?= $user_a_modifier ? '' : 'required' ?>>
                            </div>

                            <button type="submit" class="btn btn-success"
                                onclick="
                                    let ancienRole = '<?= $user_a_modifier['role'] ?? '' ?>';
                                    let nouveauRole = document.querySelector('[name=role]').value;

                                    if (ancienRole === 'Utilisateur' && nouveauRole === 'Administrateur') {
                                        return confirm('Si vous changez le rôle d\'Utilisateur en Administrateur, toutes ses tâches seront supprimées. Voulez-vous continuer ?');
                                    }
                                    // return true;
                                ">
                                <?= $user_a_modifier ? "Enregistrer les modifications" : "Ajouter l'utilisateur" ?>
                            </button>

                            <?php if ($user_a_modifier): ?>
                                <a href="index.php" class="btn btn-secondary">Annuler</a>
                            <?php endif; ?>

                        </form>
                    </div>
                </div>
            </div>

            <!-- Colonne droite: Liste des utilisateurs -->
            <div class="col-5">
                <div class="mb-4 col-md-12 offset-1 card pb-4">
                    <?php foreach ($users as $u): ?>
                        <div class="mt-3 d-flex align-items-center text-primary-emphasis text-decoration-none ps-2 py-2 <?= ($_SESSION['idUser'] == $u['idUser']) ? 'bg-info rounded-2 shadow-sm border border-primary border-2' : ''?>">
                            <i class="bi bi-person-fill fs-2 me-3"></i>
                            <?= "<span class='fs-5' style='width:90%;'>" .htmlspecialchars($u['prenom'])." ". htmlspecialchars($u['nom']). ($u['role']==='Administrateur' ? ' (A)' : ' (U)') ."</span>"?>
                            
                            <div class="col-5 ms-4">
                                <a href="actionA.php?modifieruser=<?= $u['idUser'] ?>" class="btn btn-sm btn-primary ms-3">
                                    Modifier
                                </a>

                                <a href="actionA.php?supprimeruser=<?= $u['idUser'] ?>"
                                    class="btn btn-sm btn-danger"
                                    onclick="return confirm('Voulez-vous supprimer cet Utilisateur ?<?= $u['idUser'] ?>');">
                                    Supprimer
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ==== LISTE DES TÂCHES ==== -->
        <h2 class="mb-3">Liste des tâches 
            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
                <small class="text-muted">(Résultats pour "<?= htmlspecialchars($_GET['search']) ?>")</small>
            <?php endif; ?>
            <?php if (isset($_GET['statut']) && $_GET['statut'] !== 'tous'): ?>
                <small class="text-muted">(Filtré par statut: <?= htmlspecialchars($_GET['statut']) ?>)</small>
            <?php endif; ?>
        </h2>

        <div class="row">
            <?php if (!empty($taches)): ?>
                <?php foreach ($taches as $tache): ?>
                    <div class="col-md-4">
                        <div class="card mb-3 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <?= htmlspecialchars($tache['titre']) ?>
                                </h5>

                                <p class="card-text">
                                    <?= htmlspecialchars($tache['description']) ?>
                                </p>

                                <span class="badge bg-<?= $tache['statut'] == "terminée" ? "success" : "warning" ?>">
                                    <?= $tache['statut'] ?>
                                </span>

                                <?php if (isset($tache['created_at'])): ?>
                                    <small class="text-muted d-block mt-2">
                                        Créé le: <?= date('d/m/Y', strtotime($tache['created_at'])) ?>
                                    </small>
                                <?php endif; ?>

                                <hr>

                                <div class='row'>
                                    <h5 class='col-9'>Tâche de <?= htmlspecialchars($tache['prenom']." ". $tache['nom']) ?> 
                                        <small class="text-muted">(<?= $tache['role'] == 'Administrateur' ? 'Admin' : 'User' ?>)</small>
                                    </h5>
                                    <a href="actionA.php?supprimer=<?= $tache['id'] ?>" 
                                        class="btn btn-sm btn-danger col-3" 
                                        onclick="return confirm('Voulez-vous supprimer cette tâche ?');">
                                        Supprimer
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class='alert alert-info'>
                    <?php if (isset($_GET['search']) || isset($_GET['statut'])): ?>
                        Aucune tâche ne correspond à vos critères de recherche.
                    <?php else: ?>
                        Pas de tâche à afficher
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
    <!-- BOOTSTRAP JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>